package org.apache.giraph.subgraph;

public class SubgraphMessageStore {

}
