/**
 * 
 */
/**
 * @author simon0227
 *
 */
package org.apache.giraph.tools.benchmark;