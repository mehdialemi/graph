/**
 * 
 */
/**
 * @author ggbond
 *
 */
package org.apache.giraph.tools;