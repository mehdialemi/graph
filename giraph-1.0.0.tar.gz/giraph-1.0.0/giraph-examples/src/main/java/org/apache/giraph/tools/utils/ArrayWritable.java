package org.apache.giraph.tools.utils;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;

public class ArrayWritable extends org.apache.hadoop.io.ArrayWritable {

	public ArrayWritable() {
		super(IntWritable.class);
	}

	public ArrayWritable(Class<? extends Writable> valueClass, Writable[] values) {
		    super(valueClass, values);
	}
}
